
const { Client, GatewayIntentBits, PermissionsBitField } = require("discord.js");
const fs = require("fs");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const dbFile = "./database.json";

if (!fs.existsSync(dbFile)) {
  fs.writeFileSync(dbFile, JSON.stringify({
    fila: [],
    blacklist: [],
    ranking: {},
    pagamentos: {},
    partidaAtual: null
  }, null, 2));
}

function getDB() {
  return JSON.parse(fs.readFileSync(dbFile));
}

function saveDB(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}

function shuffle(array) {
  return array.sort(() => Math.random() - 0.5);
}

client.once("ready", () => {
  console.log(`🔥 Bot online como ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  const db = getDB();

  if (message.content === "!fila") {

    if (db.blacklist.includes(message.author.id))
      return message.reply("🚫 Você está na blacklist.");

    if (db.fila.includes(message.author.id))
      return message.reply("⚠️ Você já está na fila.");

    if (db.fila.length >= 8)
      return message.reply("⛔ Fila cheia.");

    db.fila.push(message.author.id);
    saveDB(db);

    message.reply(`✅ Entrou na fila (${db.fila.length}/8)`);

    if (db.fila.length === 8) {
      const jogadores = shuffle(db.fila);
      const time1 = jogadores.slice(0,4);
      const time2 = jogadores.slice(4,8);

      db.partidaAtual = { time1, time2 };
      db.fila = [];
      saveDB(db);

      message.channel.send("🔥 PARTIDA FORMADA 🔥");
      message.channel.send("🔵 Time 1:\n" + time1.map(id => `<@${id}>`).join("\n"));
      message.channel.send("🔴 Time 2:\n" + time2.map(id => `<@${id}>`).join("\n"));
      message.channel.send("Use !resultado 1 ou !resultado 2");
    }
  }

  if (message.content.startsWith("!resultado")) {

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return;

    if (!db.partidaAtual)
      return message.reply("❌ Não há partida ativa.");

    const vencedor = message.content.split(" ")[1];
    const time = vencedor === "1" ? db.partidaAtual.time1 : db.partidaAtual.time2;

    time.forEach(id => {
      if (!db.ranking[id]) db.ranking[id] = 0;
      db.ranking[id] += 3;
    });

    db.partidaAtual = null;
    saveDB(db);

    message.channel.send("🏆 Resultado registrado!");
  }

  if (message.content === "!ranking") {
    const ranking = Object.entries(db.ranking)
      .sort((a,b)=>b[1]-a[1])
      .slice(0,10);

    if (!ranking.length)
      return message.reply("📊 Sem dados.");

    message.channel.send(
      ranking.map((r,i)=>`${i+1}º <@${r[0]}> - ${r[1]} pts`).join("\n")
    );
  }

});

client.login(process.env.TOKEN);
