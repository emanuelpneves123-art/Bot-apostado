const { Client, GatewayIntentBits, PermissionsBitField, ChannelType } = require("discord.js");
const fs = require("fs");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const dbFile = "./database.json";

if (!fs.existsSync(dbFile)) {
  fs.writeFileSync(dbFile, JSON.stringify({
    fila: [],
    blacklist: [],
    ranking: {},
    pagamentos: {}
  }, null, 2));
}

function getDB() {
  return JSON.parse(fs.readFileSync(dbFile));
}

function saveDB(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}

process.on("unhandledRejection", console.error);
process.on("uncaughtException", console.error);

client.once("ready", () => {
  console.log(`✅ Bot PRO online como ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const db = getDB();

  if (message.content === "!fila") {

    if (db.blacklist.includes(message.author.id))
      return message.reply("🚫 Você está na blacklist.");

    if (db.fila.includes(message.author.id))
      return message.reply("⚠️ Você já está na fila.");

    db.fila.push(message.author.id);
    saveDB(db);

    message.reply(`✅ Entrou na fila (${db.fila.length}/8)`);

    if (db.fila.length === 8) {
      const time1 = db.fila.slice(0,4);
      const time2 = db.fila.slice(4,8);

      message.channel.send("🔥 PARTIDA FORMADA 🔥");

      message.channel.send("🔵 Time 1:\n" + time1.map(id => `<@${id}>`).join("\n"));
      message.channel.send("🔴 Time 2:\n" + time2.map(id => `<@${id}>`).join("\n"));

      db.fila = [];
      saveDB(db);
    }
  }

  if (message.content === "!sair") {
    db.fila = db.fila.filter(id => id !== message.author.id);
    saveDB(db);
    message.reply("🚪 Saiu da fila.");
  }

  if (message.content.startsWith("!blacklist")) {

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return;

    const user = message.mentions.users.first();
    if (!user) return;

    db.blacklist.push(user.id);
    saveDB(db);

    message.reply("🚫 Adicionado à blacklist.");
  }

  if (message.content === "!ticket") {

    const canal = await message.guild.channels.create({
      name: `ticket-${message.author.username}`,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        {
          id: message.guild.id,
          deny: ["ViewChannel"]
        },
        {
          id: message.author.id,
          allow: ["ViewChannel"]
        }
      ]
    });

    canal.send(`🎫 Ticket criado para <@${message.author.id}>`);
  }

  if (message.content === "!pagar") {

    db.pagamentos[message.author.id] = "PENDENTE";
    saveDB(db);

    message.reply("💰 Envie o comprovante no ticket.");
  }

  if (message.content === "!ranking") {

    const ranking = Object.entries(db.ranking)
      .sort((a,b)=>b[1]-a[1])
      .slice(0,10);

    if (ranking.length === 0)
      return message.reply("📊 Sem dados ainda.");

    message.reply(
      ranking.map((r,i)=>`${i+1}º <@${r[0]}> - ${r[1]} pts`).join("\n")
    );
  }

});

const TOKEN = process.env.TOKEN;
client.login(TOKEN);
